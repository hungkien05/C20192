#include <stdio.h>

int main()
{
	int i;
	printf("%8d", i);
	return 0;
}
