#include <stdio.h>
#include <stdlib.h>

int main()
{
	int n=0;
	while (getchar() != EOF) n++;
	printf("%d",n);
	return 0;
}
