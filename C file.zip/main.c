#include <stdio.h>
#include <stdlib.h>

int main()
{
	int x;
	printf("nhap: ");
	scanf("%d", &x);
    if (x>7) printf("1");
    else printf("0");
    
    return 0;
}
