#include <stdio.h>
#include <string.h>

int main() {
	char s[15],x[30]="035";
	strcpy(s,"01653178560");
//	x="035";
	int i;
	for (i=0; i<strlen(s)-3; i++) {
		s[i]=s[i+4];
	}
	puts(s);
	strcat(x,s);
	puts(x);
	return 0;
} 
