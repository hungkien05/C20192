#include <stdio.h>

int main()
{
	char ch= getchar();
	printf("%c\n", ch);
	return 0;
}
