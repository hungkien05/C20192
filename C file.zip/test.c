#include <stdio.h>

int main()
{
	int i=1, k=3;
	for (i=1; i<=k; ++i) 
	printf("14");
	return 0;
}
