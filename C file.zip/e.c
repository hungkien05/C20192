#include <stdio.h>
#include <stdlib.h>

int main()
{
	
	float a=4;
	float b=7;
	float c=a/b;
	printf("%f\n", c);
	
    float so[3]= {3.4,7.2};
    printf("in ra so %f %f %f\n", so[0],so[1],so[2]);
	
	char mangkitu[] = "richchoi";
	mangkitu[1]='y';
	printf("mang: %s\n", mangkitu);
	
	int k= 10;
	int n=19;
	if (k==10) && (n>k)
	{
		printf("%d\n",k);
		printf("ez vcl");
	}
	else printf("dcmm");
	
	return 0;
}
