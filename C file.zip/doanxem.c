#include <stdio.h>

int main()
{
	printf("doan xem\n");
	return 0;
}

