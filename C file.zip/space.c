#include <stdio.h>

int main()
{
	int i;
	printf("%-10s","vinadu");
	printf("real rap");
	return 0;
}
