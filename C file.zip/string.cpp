#include <iostream>
using namespace std;

int main()
{
	string s="hello there";
	string s1=", richchoi";
	string s2=s+s1;
	cout << s2 << endl;
	return 0;
}
