#include <stdio.h>

int main()
{
	int doses[] = {1, 3, 2, 1000};
	printf("Issue dose %i",3[doses] );
	return 0;
}
