#include <stdio.h>

int n=14;

void abc()
{
	printf("%d\n", n);
}
int main()
{
	printf("%d\n", sizeof(long));
	abc();
	return 0;
}
