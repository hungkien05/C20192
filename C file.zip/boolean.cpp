#include <iostream>
using namespace std;

int main()
{
	bool kt=true;
	cout << kt << endl;
	wchar_t c='h';
	cout << (char)c << endl;
	return 0;
}
